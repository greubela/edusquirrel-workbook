# E-Mail Simulator

Simulation eines E-Mail-Postfach, in dem die Erkennung von Phishing-Nachrichten geübt werden kann. Bestandteil des Arbeitsheftes "Phishing entlarven!"

## Voraussetzungen
- Python 3.10 oder neuer installiert (https://www.python.org/downloads/)

## Installation & Start
1. Terminal im Projektordner öffnen
2. Virtuelle Umgebung anlegen und aktivieren:

   macOS/Linux:
     python3 -m venv venv
     source venv/bin/activate

   Windows:
     py -3 -m venv venv
     venv\Scripts\activate.bat

3. Abhängigkeiten installieren:
     pip install -r requirements.txt

4. Programm starten:
     python E-Mail-Postfach.py